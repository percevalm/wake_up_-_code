﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication5.Models
{
    public class Students
    {
        public int ID { get; set;}
        public string Firstname { get; set;}
        public string Lastname { get; set;}
        public string Nationality { get; set;}
        public string Email { get; set; }
        public bool Gender { get; set; }
    }
}
